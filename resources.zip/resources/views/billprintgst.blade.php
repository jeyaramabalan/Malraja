<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    @include('layouts.header')
    <style>
        * {
            font-size: 20px;
            font-family: 'Calibri';
        }

        /* td,
        th,
        tr,
        table {
            border-top: 1px solid black;
            border-collapse: collapse;
        } */

        td.description,
        th.description {
            width: 400px;
            max-width: 400px;
        }
        
        td.description1,
        th.description1 {
            width: 400px;
            max-width: 400px;
        }

        td.quantity,
        th.quantity {
            width: 80px;
            max-width: 80px;
            word-break: break-all;
        }

        td.price,
        th.price {
            width: 133px;
            max-width: 133px;
            word-break: break-all;
        }

        .centered {
            text-align: center;
            align-content: center;
        }
        .big {
            font-size: 36px;
            text-align: center;
            align-content: center;
            font-weight: bold;
        }

        .ticket {
            width: 555px;
            max-width: 555px;
        }

        img {
            max-width: inherit;
            width: inherit;
        }

        @media print {
            .hidden-print,
            .hidden-print * {
                display: none !important;
            }
        }
    </style>

    <body>
        <div class="ticket mr-1 ml-2">
        <p style="background-image: url('logo.png');">
            <div class="big"><span style="font-size: 14px">
                அருள்மிகு முருகன் துணை</span><br/>
            மால்ராஜா டிரேடர்ஸ் </div>
            <p class="centered"><b>
                3/158, பெரும்பாக்கம் மெயின் ரோடு,
<br/>
மேடவாக்கம், சென்னை - 600100<br/>
                தொலைபேசி :  044 22770590<br/>
                செல்   : 9444390390, 9444858932
                <br/>
                <span style="font-size: 16px">GSTIN : 33CWTPS0135D1ZK</span></p>
            <div class="row mb-1">
                <div class="col-6">
                    <span>{{ __('bill.to') }}</span></br>
                    <span>{{$orders->customerName}}</span></br>
                </div>
                <div class="col-6">
                    <div class="row">
                        <div class="col-6">
                            <div class="text-left">{{ __('bill.bill_no') }}: </div>
                        </div>
                        <div class="col-6">
                            <div class="text-right">{{$orders->bill_id}}</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="text-left">{{ __('bill.date') }}: </div>
                        </div>
                        <div class="col-6">
                            <div class="text-right"><?php echo date('d-m-Y', strtotime($orders->date)); ?></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="text-left">{{ __('bill.time') }}: </div>
                        </div>
                        <div class="col-6">
                            <div class="text-right"><?php echo date('h:i A', strtotime($orders->created_at)); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <table class="table-bordered">
                <thead>
                    <tr style="height:50px">
                        <th align="left" class="description">பொருள் பெயர்</th>
                        <th align="left" class="quantity">QTY</th>
                        <th align="left" class="price">விலை</th>
                        <th align="left" class="price">தொகை</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($order_items as $item)
                        <tr style="height:40px">
                            <td class="description">{{$item->product_name}}</td>
                            <td align="center" class="quantity">{{$item->quantity}}</td>
                            <td align="right" class="price">{{number_format($item->quantity_price, 2)}}</td>
                            <td align="right" class="quantity">{{number_format(($item->quantity * $item->quantity_price), 2)}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table><br/>
            <div class="row">
                <div class="col-2">
                    <span style="font-size: 16px" >{{ __('bill.total_items') }}</span>
                </div>
                <div class="col-1">
                    <span style="font-size: 16px" >{{$total_items}}</span>
                </div>
                <div class="col-6 text-right">
                    <span>தொகை</span>
                </div>
                <div class="col-3 text-right">
                    <span>₹{{number_format($orders->total - $totalGst, 2)}}</span>
                </div>
            </div>
            <div class="row">
                <div class="col-2">
                    <span style="font-size: 16px" >{{ __('bill.total_qty') }}</span>
                </div>
                <div class="col-1">
                    <span style="font-size: 16px" >{{$total_quantity}}</span>
                </div>
                <div class="col-6 text-right">
                    <span>வரி</span>
                </div>
                <div class="col-3 text-right">
                    <span>₹{{number_format($totalGst, 2)}}</span>
                </div>
            </div>
            <div class="row text-right">
                <div class="col-9">
                    <span>மொத்தம்</span>
                </div>
                <div class="col-3">
                    <span>₹{{number_format($orders->total, 2)}}</span>
                </div>
            </div></br>
            <br>
            <p class="centered">நன்றி! மீண்டும் வருக.</p>
        </div>
        <button id="btnPrint" class="hidden-print">{{ __('bill.print') }}</button>
        <script src="script.js"></script>
    </body>
    <script>
        const $btnPrint = document.querySelector("#btnPrint");
        $btnPrint.addEventListener("click", () => {
            window.print();
        });
    </script>
</html>