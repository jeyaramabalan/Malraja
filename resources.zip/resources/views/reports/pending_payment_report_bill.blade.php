<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@include('layouts.header')
<style>
/* ... existing styles remain unchanged ... */
</style>
<div class="ticket mr-1 ml-2">
<body>
<h2 align="center">Malraja Traders</h3>
<p align="center">
<b>{{ __('reports.stock_report') }}</p>
<p align="center"><b>{{$date}}</p>
<table width="100%" border="1" cellpadding="2" cellspacing="0">
<thead>
<tr>
<th>{{ __('reports.bill_no') }}</th>
<th>{{ __('reports.customer') }}</th>
<th>{{ __('reports.amount') }}</th>
<th>{{ __('reports.pending') }}</th>
</tr>
</thead>
<body>
@foreach ($completeData as $item)
<tr style="height:40px">
<td class="quantity">{{$item->bill_id}}</td>
<td align="center" class="description">{{$item->customerName}}</td>
<td align="right" class="price">{{number_format($item->total, 2)}}</td>
<td align="right" class="quantity1">{{number_format($item->paymentPending, 2)}}</td>
</tr>
@endforeach
</body>
</table>
<button id="btnPrint" class="hidden-print">{{ __('reports.print') }}</button>
    </body>
</div>
<script>
    const $btnPrint = document.querySelector("#btnPrint");
    $btnPrint.addEventListener("click", () => {
        window.print();
    });
</script>
</html>