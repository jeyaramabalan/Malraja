@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Products</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="product_form" method="POST" action="{{$route}}">
                            <?php if(isset($product->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label>Category</label>
                                    <select class="form-control" name="cat_id" style="width: 100%;" required>
                                      <option value="" selected="selected">Select Category</option>
                                      <?php echo $category; ?>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                      <label>Product Name</label>
                                      <input class="form-control" type="text" name="name" id="name" value="<?php if(isset($product->name)){echo $product->name;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                      <label>Tamil Name</label>
                                      <input class="form-control" type="text" name="tname" id="tname" value="<?php if(isset($product->tamil_name)){echo $product->tamil_name;} ?>">
                                  </div>
                                  <div class="form-group">
                                      <label>Product Code</label>
                                      <input class="form-control" type="text" name="code" id="code" value="<?php if(isset($product->code)){echo $product->code;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                      <label>Product Unit</label>
                                      <select class="form-control" name="unit" id="unit" style="width: 100%;" required>
                                        <option value="" selected="selected">Select Unit</option>
                                        <?php echo $units; ?>
                                      </select>
                                  </div>
                                  <div class="form-group">
                                      <label>Product HSN</label>
                                      <select class="form-control" name="hsn" id="hsn" style="width: 100%;" required>
                                        <option selected="selected">Select HSN</option>
                                        <?php echo $hsn; ?>
                                      </select>
                                  </div>
                                  <div class="form-group">
                                    <label>Purchase Rate</label>
                                    <input class="form-control" type="text" name="prate" id="prate" value="<?php if(isset($product->purchase_rate)){echo $product->purchase_rate;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                      <label>Whole Sale Rate</label>
                                      <input class="form-control" type="text" name="mrp" id="mrp" value="<?php if(isset($product->mrp)){echo $product->mrp;} ?>" required>
                                  </div>
                                </div>
                                <!-- /.col -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Customer Rate</label>
                                        <input class="form-control" type="text" name="crate" id="crate" value="<?php if(isset($product->customer_rate)){echo $product->customer_rate;} ?>" required>
                                    </div>
                                  <div class="form-group">
                                      <label>GST</label>
                                      <input class="form-control" type="text" name="gst" id="gst" value="<?php if(isset($product->gst)){echo $product->gst;}else{echo 0;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                    <label>SGST</label>
                                    <input readonly="true" class="form-control" type="text" name="sgt" id="sgt" value="<?php if(isset($product->sgt)){echo $product->sgt;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                    <label>CGST</label>
                                    <input readonly="true" class="form-control" type="text" name="cgst" id="cgst" value="<?php if(isset($product->cgst)){echo $product->cgst;} ?>" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Additional Tax</label>
                                    <input class="form-control" type="text" name="atax" id="atax" value="<?php if(isset($product->additional_tax)){echo $product->additional_tax;}else{echo 0;} ?>">
                                  </div>
                                  <div class="form-group">
                                    <label>Final Price</label>
                                    <input class="form-control" type="text" name="fprice" id="fprice" value="<?php if(isset($product->final_price)){echo $product->final_price ;} ?>" required>
                                  </div>
                                </div>
                                <div class="col-12">
                                    <input type="hidden" name="id" value="<?php if(isset($product->id)){echo $product->id;} ?>">
                                  <input class="btn btn-success float-right" type="submit" value="<?php if(isset($product->id)){echo "Update Product";}else{echo "Add Product";}?>" onclick="validate()">
                                </div>
                                <!-- /.col -->
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        $(document).on('click', '#product_form', function (e) {
            $("form#product_form").validate({
                rules: {
                    name: { required: true},
                    cat_id: { required: true},
                    code: {
                        required: {
                            depends:function(){
                                $(this).val($.trim($(this).val()));
                                return true;
                            }
                        },
                        code: true
                    },
                    category:{required:true},
                    unit: { required: true},
                    prate: { required: true},
                },
                messages: {
                    name: { required: "Please enter name"},
                    cat_id: { required: "Please select product category"},
                    code: { required: "Please enter code"},
                    category: { required: "Please select category"},
                    prate: { required: "Please enter purchase rate"},
                    unit: { required: "Please select unit"},
                },
                focusInvalid: true,
                invalidHandler: function () {
                    $(this).find(":input.error:first").focus();
                }
            });
        });
    });
    
            $(document).ready(function() {
            $('#gst').keyup(function(ev) {
                var total = $('#crate').val() * 1;
                var gstvalue = $('#gst').val() * 1;
                var addlvalue = $('#atax').val() * 1;

                var tot_price =  (total - (total * (100/(100+gstvalue))));

                var tot_price1 =  (total - (total * (100/(100+addlvalue))));


                var tot_netprice = (total - (tot_price+tot_price1)).toFixed(2);
                var divobj = document.getElementById('fprice');
                
                divobj.value = tot_netprice;
                var sum_gst  = gstvalue/ 2;
                var divsum = document.getElementById('cgst');
                divsum.value = sum_gst;
                var divsgst = document.getElementById('sgt');
                divsgst.value = sum_gst;

            });
            $('#atax').keyup(function(ev) {
                var total = $('#crate').val() * 1;
                var gstvalue = $('#gst').val() * 1;
                var addlvalue = $('#atax').val() * 1;



                var tot_price =  (total - (total * (100/(100+gstvalue))));

                var tot_price1 =  (total - (total * (100/(100+addlvalue))));

                var tot_netprice = total - (tot_price+tot_price1).toFixed(2);
                var divobj = document.getElementById('fprice');

                divobj.value = tot_netprice;
                var sum_gst  = gstvalue/ 2;
                var divsum = document.getElementById('cgst');
                divsum.value = sum_gst;
                var divsgst = document.getElementById('sgt');
                divsgst.value = sum_gst;

            });
            $('#crate').keyup(function(ev) {
                var total = $('#crate').val() * 1;
                var gstvalue = $('#gst').val() * 1;
                var addlvalue = $('#atax').val() * 1;
               var tot_price =  (total - (total * (100/(100+gstvalue))));

                var tot_price1 =  (total - (total * (100/(100+addlvalue))));

                var tot_netprice = total - (tot_price+tot_price1).toFixed(2);
                var divobj = document.getElementById('fprice');

                divobj.value = tot_netprice;
                var sum_gst  = gstvalue / 2;
                var divsum = document.getElementById('cgst');
                divsum.value = sum_gst;
                var divsgst = document.getElementById('sgt');
                divsgst.value = sum_gst;

            });

        });

    </script>
@endsection