@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Claimed Details</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Claimed Details</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="product_form" method="POST" action="{{$route}}">
                            <?php if(isset($unit->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Vendor</label>
                                        <select class="form-control select2" name="vendor_id" style="width: 100%;" required>
                                          <option selected="selected">Select Vendor</option>
                                          <?php echo $vendors_option; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Claimed By</label>
                                        <select class="form-control" name="claimed_by" style="width: 100%;" required>
                                        <option selected="selected">Select User</option>
                                        <?php echo $admin_option; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Amount</label>
                                        <input class="form-control" type="number" name="amount" id="amount" required>
                                    </div>     
                                </div>
                                <!-- /.col -->
                                <div class="col-md-6">                               
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input class="form-control" type="date" name="date" id="date">
                                    </div> 
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" name="desc" id="desc"></textarea>
                                    </div>                                  
                                    <div class="col-12">
                                        <input type="hidden" name="id">
                                        <input class="btn btn-success float-right" type="submit" value="Add Claimed" onclick="validate()">
                                      </div>
                                <!-- /.col -->
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        // $(document).on('click', '#product_form', function (e) {
        //     $("form#product_form").validate({
        //         rules: {
        //             name: { required: true},
        //             code: { required: true},
        //             category:{required:true},
        //             unit: { required: true},
        //         },
        //         messages: {
        //             name: { required: "Please enter name"},
        //             code: { required: "Please enter code"},
        //             category: { required: "Please select category"},
        //             unit: { required: "Please enter unit"},
        //         },
        //         focusInvalid: true,
        //         invalidHandler: function () {
        //             $(this).find(":input.error:first").focus();
        //         }
        //     });
        // });
    });
    
           
    </script>
@endsection