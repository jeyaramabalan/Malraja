@extends('layouts.app')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Orders View</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="   ">Home</a></li>
                        <li class="breadcrumb-item active">Order View</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table">
                                <tbody class="row-hover">
                                    <tr class="row-1 odd">
                                        <td class="column-1">Order Id</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3">{{ $order->bill_id }}</td>
                                        <td class="column-1">Bill Date</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3">{{ $order->date }}</td>
                                    </tr>
                                    <tr class="row-4 even" style="border-bottom: 1px solid rgba(26,54,126,0.125);">
                                        <td class="column-1">Customer Name</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3"> {{ $order->customerName }} </td>
                                        <td class="column-1">Employee Name</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3"> {{ $order->userName }}</td>
                                    </tr>
                                </tbody>
                            </table>

                            <div class="card-body p-0">
                                <div>
                                    <table class="table table-striped table-bordered" id="" cellspacing="0"
                                        cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <th rowspan="2" class="text-center" width="400">Category</th>
                                                <th rowspan="2" class="text-center" width="400">Product Name</th>
                                                <th rowspan="2" class="text-center" width="400">Quantity</th>
                                                <th rowspan="2" class="text-center" width="100">Free Item</th>
                                                <th rowspan="2" class="text-center" width="300">Rate<br><small>(Rs)</small></th>
                                                <th rowspan="2" class="text-center" width="300">Gross Rate<br><small>(Rs)</small></th>
                                                <th colspan="2" class="text-center">Discount</th>
                                                <th colspan="2" class="text-center" width="100">GST</th>
                                                <th rowspan="2" width="100">Total<br><small>(Rs)</small></th>
                                            </tr>
                                            <tr>
                                                <th width="100">%</th>
                                                <th width="300">Amt</th>
                                                <th width="100">%</th>
                                                <th width="300">Amt</th>
                                            </tr>
                                            @foreach ($order_items as $item)
                                            <tr>
                                                <td>{{$item->category_name}}</td>
                                                <td>{{$item->product_name}}</td>
                                                <td>{{$item->quantity}}</td>
                                                <td>0</td>
                                                <td>{{$item->quantity_price}}</td>
                                                <td>{{$item->quantity_price * $item->quantity}}</td>
                                                <td>0 </td>
                                                <td>0 </td>
                                                <td>{{$item->gst}}</td>
                                                <td>{{($item->quantity_price * $item->gst) / 100}}</td>
                                                <td><div class="align-right">{{$item->amount}}</div></td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <td colspan="8">
                                                </td>
                                                <td>Total </td>
                                                <td>
                                                    <div class="text-right">Rs.{{$order->total}}</div>
                                                </td>
                                            </tr>


                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </section>
@endsection
