@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Orders</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Orders</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="vendor_form" method="POST" action="{{$route}}">
                            @method('POST')
                            @csrf
                            <div class="row">
                                {{-- <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Customer</label>
                                        <select class="form-control select2" onchange="getCustomerName(this.value)" id="e5" name="cust_id1" style="width: 100%;" required>
                                          <option value="" selected="selected">Select Customer</option>
                                          <?php echo $customers; ?>
                                        </select>
                                      </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" class="form-control" name="name" id="name" value="">
                                        <input type="hidden" class="form-control" name="cust_id" id="cust_id" value="">
                                      </div>
                                </div> --}}
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input type="date" name="date" class="form-control" id="date">
                                      </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select onchange="showDetails(this.value)" class="form-control select2" name="payment_method_id" style="width: 100%;" required>
                                          <option selected="selected" value="Cash">Cash</option>
                                          <option value="UPI">UPI</option>
                                          <option value="Mixed">Mixed</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div id="cash_upi" style="display: none" class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class=""><b>UPI</b></label>
                                        <input onchange="getCashAmount(this.value)" type="number" class="form-control" min="1" name="upi" id="upi" value="0">
                                      </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class=""><b>Cash</b></label>
                                        <input readonly type="number" class="form-control" min="1" id="cash" name="cash" value="0">
                                      </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Category</label>
                                        <select class="form-control select2" onchange="getProduct(this)" name="cat_id" style="width: 100%;" required>
                                          <option selected="selected">Select Category</option>
                                          <?php echo $category; ?>
                                        </select>
                                      </div>
                                </div>
                                <!-- /.col -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Products</label>
                                        <select class="form-control select2" onchange="getSelectedProduct(this)" id="pro_id" name="pro_id" style="width: 100%;" required>
                                          <option selected="selected">Select Product</option>
                                        </select>
                                      </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class=""><b>Quantity</b><span id="ava_qt"></span></label>
                                        <input type="number" class="form-control" min="1" id="pro_qty" value="1">
                                        <input type="hidden" class="form-control" id="sel_pro_obj">
                                      </div>
                                </div>
                                <div class=" form-group col-md-3" style="padding-top: 30px;">
                                    <button type="button" onclick="addToCart()" id="add_list" class="form-control btn btn-outline-primary">Add To List</button>
                                </div>
                                <!-- /.col -->
                            </div>
                            <div class="row ml-3">
                                {{-- <div class="col-md-3">
                                    <div class="form-group">
                                        <input class="form-check-input" type="checkbox" name="ischeck" value="1" id="ischeck">
                                        <label class="form-check-label" for="flexCheckDefault">
                                          Is POS
                                        </label>
                                    </div>
                                </div> --}}
                                {{-- <div class="col-md-3 pl-2">
                                    <div class="form-group">
                                        <input class="form-check-input" type="checkbox" name="ispaid" value="1" id="ispaid">
                                        <label class="form-check-label" for="flexCheckDefault">
                                          Is Paid
                                        </label>
                                    </div>
                                </div> --}}
                                <div class="col-md-3 pl-2">
                                    <div class="form-group">
                                        <input class="form-check-input" type="checkbox" name="iswhole" value="1" id="iswhole">
                                        <label class="form-check-label" for="flexCheckDefault">
                                          Is WholeSale
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-3 pl-2">
                                    <div class="form-group">
                                        <input class="form-check-input" type="checkbox" name="isPrint" value="1" id="isPrint">
                                        <label class="form-check-label" for="flexCheckDefault">
                                          Save & Print
                                        </label>
                                    </div>
                                </div>
                            </div>
                        <div class="table-responsive" id="order_table">
                    
                            <!-- My table 124 -->        
                            
                            <table class="table table-striped table-bordered show-cart"><thead class="text-center"><tr><th rowspan="2">S.No</th><th rowspan="2" width="400">Category</th><th rowspan="2" width="400">Prod_Name</th><th rowspan="2" width="400">Quantity</th><th rowspan="2" width="100">Unit</th><th rowspan="2" width="300">price</th><th rowspan="2" width="300">Rate</th><th rowspan="2" width="300">G Rate</th><th rowspan="2" width="100">Remove</th><th colspan="2" class="text-center">Discount</th><th colspan="2" class="text-center" width="100">GST</th><th colspan="2" class="text-center" width="100">ADT</th><th rowspan="2" width="100">Grand Total<br><small>(Rs)</small></th></tr><tr><th width="100">%</th><th width="300">Amt</th><th width="100">%</th><th width="300">Amt</th><th width="100">%</th><th width="300">Amt</th></tr></thead></table>
                            <div class="col-md-12 text-right text-black">
                            <h4>Total : Rs <span class="total-cart"></span> </h4></div>
                             <div style="text-align:center;">
                            <input class="btn btn-outline-warning " id="check1" type="submit" value="Place Order" />
                            <input id="total_amount" name="total_amount" type="hidden" />
                          </div>
                            <!-- My table -->
                        
                        
                        
                        </div>
                    </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        document.getElementById("date").valueAsDate = new Date();
        $(document).on('click', '#vendor_form', function (e) {
            $("form#vendor_form").validate({
                rules: {
                    name: { required: true},
                    address: { required: true},
                    mobile: { required: true, minlength:10},
                },
                messages: {
                    name: { required: "Please enter name"},
                    mobile: { required: "Please enter mobile"},
                    address: { required: "Please enter address"},
                },
                focusInvalid: true,
                invalidHandler: function () {
                    $(this).find(":input.error:first").focus();
                }
            });
        });

    });

    function getProduct(sel)
    {
        $.ajax({
            type:"post",
            url: '{{route("get-category-product")}}',
            data:{_token: '{{csrf_token()}}', id:sel.value},
            success:function(res)
            {
                if(res)
                {
                    var res = $.parseJSON(res);
                    $('#pro_id')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value="0">Select Product</option>')
                        .val()
                    ;
                    $.each(res,function(key, value) {
                        $('#pro_id').append($("<option/>", {
                            value: value.id,
                            text: value.name
                        }));
                    });
                }
            }        
        });
    }
    
    function getSelectedProduct(sel)
    {
        $.ajax({
           type:"post",
           url: '{{route("get-product")}}',
           data:{_token: '{{csrf_token()}}', id:sel.value},
           success:function(res)
           {
                if(res)
                {
                    $("#sel_pro_obj").val(res);
                    var res = $.parseJSON(res);
                    $("#ava_qt").text(" (Available " + res.stock + ") ");
                }
           }
    
        });
    }
    
    function addToCart()
    {
        var iswhole = 0;
        if($("#iswhole").is(':checked')) {
            iswhole = 1;
        } else {
            iswhole = 0;
        }
        var res = $.parseJSON($("#sel_pro_obj").val());
        if(res.stock < $("#pro_qty").val()) {
            alert("Product Stock Not Available");
            return;
        }
        var proId = $("#pro_id").val();
        var proQty = $("#pro_qty").val();
        $.ajax({
           type:"post",
           url: '{{route("add-to-cart")}}',
           data:{_token: '{{csrf_token()}}', proId:proId, proQty:proQty, iswhole:iswhole},
           success:function(res)
           {
                if(res)
                {
                    var output = $.parseJSON(res);
                    $('.show-cart').html(output.cart);
                    $('.total-cart').text(output.total);
                    $('#total_amount').val(output.total);
                }
           }
        });
    }

    function removeToCart(id)
    {
        var proId = id;
        var proQty = 0;
        $.ajax({
           type:"post",
           url: '{{route("add-to-cart")}}',
           data:{_token: '{{csrf_token()}}', proId:proId, proQty:proQty},
           success:function(res)
           {
                if(res)
                {
                    var output = $.parseJSON(res);
                    $('.show-cart').html(output.cart);
                    $('.total-cart').text(output.total);
                    $('#total_amount').val(output.total);
                }
           }
        });
    }

    function plusCartQty(id, proQty)
    {
        var iswhole = 0;
        if($("#iswhole").is(':checked')) {
            iswhole = 1;
        } else {
            iswhole = 0;
        }
        $.ajax({
           type:"post",
           url: '{{route("add-to-cart")}}',
           data:{_token: '{{csrf_token()}}', proId:id, proQty:proQty + 1, iswhole:iswhole},
           success:function(res)
           {
                if(res)
                {
                    var output = $.parseJSON(res);
                    $('.show-cart').html(output.cart);
                    $('.total-cart').text(output.total);
                    $('#total_amount').val(output.total);
                }
           }
        });
    }

    function minusCartQty(id, proQty)
    {
        var iswhole = 0;
        if($("#iswhole").is(':checked')) {
            iswhole = 1;
        } else {
            iswhole = 0;
        }
        $.ajax({
           type:"post",
           url: '{{route("add-to-cart")}}',
           data:{_token: '{{csrf_token()}}', proId:id, proQty:proQty - 1, iswhole:iswhole},
           success:function(res)
           {
                if(res)
                {
                    var output = $.parseJSON(res);
                    $('.show-cart').html(output.cart);
                    $('.total-cart').text(output.total);
                    $('#total_amount').val(output.total);
                }
           }
        });
    }

    function getCustomerName(value)
    {
        if(value.indexOf("-") > 0) {
            var temp = value.split("-");
            $('#name').val(temp[1]);
            $('#cust_id').val(temp[0]);
        } else {
            $('#cust_id').val("");
            $('#name').val("");
        }
    }

    // Item Rate input -- Fixing values
    $('.show-cart').on("change", ".item-rate", function(event) {
        var rate = $(this).val();
        var proId = $(this).data('id');
        var proQty = $("#number"+proId).val();
        $.ajax({
           type:"post",
           url: '{{route("add-to-cart")}}',
           data:{_token: '{{csrf_token()}}', proId:proId, proQty:proQty, rate:rate},
           success:function(res)
           {
                if(res)
                {
                    var output = $.parseJSON(res);
                    $('.show-cart').html(output.cart);
                    $('.total-cart').text(output.total);
                    $('#total_amount').val(output.total);
                }
           }
        });
    });

    function showDetails(selectedPayment) {
        if(selectedPayment == "Mixed") {
            $('#cash_upi').show();
        } else {
            $('#cash_upi').hide();
        }
    }
    
    
    function getCashAmount(upi) {
        var total_amount = $('#total_amount').val();
        $('#cash').val(total_amount - upi);
    }
    
</script>
@endsection