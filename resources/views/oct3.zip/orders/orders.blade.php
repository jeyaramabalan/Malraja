@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Orders</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Orders</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <a href="{{$route}}" class="btn btn-primary float-right">Add</a>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="POST" action="{{route('daily-profit')}}">
                            @method('POST')
                            @csrf
                            <div class="row">
                                <div class="col-3">
                                    <label>Status</label>
                                    <select class="form-control" onchange="fetchTable()" id="status" style="width: 100%;" required="" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                    <option selected="selected" value="">Select Status</option>
                                    <option value="1">Pending</option>
                                    <option value="2">Confirmed</option>
                                    <option value="3">Payment Pending</option>
                                    <option value="4">Completed</option>
                                    </select>
                                </div>
                                <div class="col-3">
                                    <label>Order Type</label>
                                    <select class="form-control" onchange="fetchTable()" id="type" style="width: 100%;" required="" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                    <option selected="selected" value="">Select Order Type</option>
                                    <option value="1">Delivery</option>
                                    <option value="2">POS</option>
                                    </select>
                                </div>
                                <div class="col-3">
                                    <label>Date</label>
                                    <input class="form-control" type="text" id="datetimepicker" name="date" />
                                </div>
                                <div class="col-3">
                                    <label>.</label>
                                    <input type="buton" onclick="fetchTableWithdate()" class="form-control btn btn-success" value="View"/>
                                </div>
                            </div>
                        </form>
                        <div class="tbale-responsive">
                        <table style="width: 100%;" id="example1" class="table table-bordered table-striped export-table">
                            <thead>
                                <tr>
                                    <th>SNO</th>
                                    <th>Bill No</th>
                                    <th>Customer</th>
                                    <th>Order Type</th>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                    <th>Pending</th>
                                    <th>Created By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                        </div>
                        
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>

<script>
    $(document).ready(function() {
        fetchTable();
    });
        
    function fetchTable() 
    {
        var status = $('#status').val();
        var types = $('#type').val();
        let table = $('#example1');
        table.DataTable().clear().destroy();
        dTable = table.DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25,
            deferRender: true,
            responsive: true,
            info: true,
            paging:true,
            autoWidth: false,
            searching: false,
            sScrollX: '100%',
            dom: 'Bfrtip',
            buttons: [
            ],
            stateSave: true,
            ajax: {
                url: '{{route("get-order-list")}}',
                type: 'POST',
                dataType:'json',
                data:{_token: '{{csrf_token()}}', status:status, types:types},
            },
            aoColumnDefs:[{bSortable:false,aTargets:[0,6]}],
            columns: [
                {data:'sno'},
                {data:'bill_id'},
                {data:'customerName'},
                {data:'type'},
                {data:'date'},
                {data:'payment_method'},
                {data:'orderStatus'},
                {data:'total'},
                {data:'paymentPending'},
                {data:'userName'},
                {data:'action'},
            ]
        });
    }   

    function fetchTableWithdate() 
    {
        var date = $("#datetimepicker").val();
        var status = $('#status').val();
        var types = $('#type').val();
        let table = $('#example1');
        table.DataTable().clear().destroy();
        dTable = table.DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25,
            deferRender: true,
            responsive: true,
            info: false,
            paging:true,
            autoWidth: false,
            searching: false,
            sScrollX: '100%',
            dom: 'Bfrtip',
            buttons: [
            ],
            stateSave: true,
            ajax: {
                url: '{{route("get-order-list")}}',
                type: 'POST',
                dataType:'json',
                data:{_token: '{{csrf_token()}}', status:status, types:types, date:date},
            },
            aoColumnDefs:[{bSortable:false,aTargets:[0,6]}],
            columns: [
                {data:'sno'},
                {data:'bill_id'},
                {data:'customerName'},
                {data:'type'},
                {data:'date'},
                {data:'payment_method'},
                {data:'orderStatus'},
                {data:'total'},
                {data:'paymentPending'},
                {data:'userName'},
                {data:'action'},
            ]
        });
    }   

    function updateStatus(orderId, statusId) 
    {
        $('#update-btn'+orderId).hide();
        $('#spinner'+orderId).show();
        $.ajax({
           type:"post",
           url: '{{route("status-update")}}',
           data:{_token: '{{csrf_token()}}', id:orderId, status:statusId},
           success:function(res){
            location.reload();
           }
    
        });
    }
</script>
@endsection