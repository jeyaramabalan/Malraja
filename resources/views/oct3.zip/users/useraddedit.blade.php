@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>User</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="">Home</a></li>
                    <li class="breadcrumb-item active">User</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="customer_form" method="POST" action="{{$route}}">
                            <?php if(isset($user->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input class="form-control" type="text" name="name" id="name" value="<?php if(isset($user->name)){echo $user->name;} ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Mobile</label>
                                        <input class="form-control" type="number" name="mobile" id="mobile" value="<?php if(isset($user->mobile)){echo $user->mobile;} ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input class="form-control" type="email" name="email" id="email" value="<?php if(isset($user->email)){echo $user->email;} ?>">
                                    </div>       
                                </div>
                                <!-- /.col -->
                                <div class="col-md-6">
                                    <?php if(!isset($user->password)){?>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input class="form-control" type="text" name="password" id="password">
                                    </div>
                                    <?php } ?>
                                    <div class="form-group">
                                        <label>DOB</label>
                                        <input class="form-control" type="date" name="dob" id="dob" value="<?php if(isset($user->dob)){echo $user->dob;} ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Aadhar</label>
                                        <input class="form-control" type="number" minlength="12" maxlength="12" name="aadhar" id="aadhar" value="<?php if(isset($user->aadhar_number)){echo $user->aadhar_number;} ?>">
                                    </div>                           
                                    <div class="col-12">
                                        <input type="hidden" name="id" value="<?php if(isset($user->id)){echo $user->id;} ?>">
                                        <input class="btn btn-success float-right" type="submit" value="<?php if(isset($user->id)){echo "Update User";}else{echo "Add User";}?>" onclick="validate()">
                                      </div>
                                <!-- /.col -->
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        $(document).on('click', '#customer_form', function (e) {
            $("form#customer_form").validate({
                rules: {
                    name: { required: true},
                    mobile: { required: true, minlength:10},
                },
                messages: {
                    name: { required: "Please enter name"},
                    address: { required: "Please enter address"},
                },
                focusInvalid: true,
                invalidHandler: function () {
                    $(this).find(":input.error:first").focus();
                }
            });
        });
    });           
</script>
@endsection