@extends('layouts.app')
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Orders View</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="   ">Home</a></li>
                        <li class="breadcrumb-item active">Order View</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table">
                                <tbody class="row-hover">
                                    <tr class="row-2 odd">
                                        <td class="column-1">Order Id</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3">{{ $orderId }}</td>
                                        <td class="column-1">Total Order Amount</td>
                                        <td class="column-2">:</td>
                                        <td class="column-3">{{ $orderTotal }}</td>
                                    </tr>
                                </tbody>
                            </table>

                            <div class="card-body p-0">
                                <div>
                                    <table class="table table-striped table-bordered" id="" cellspacing="0"
                                        cellpadding="0" border="0">
                                        <tbody>
                                            <tr>
                                                <th rowspan="1" class="text-center" width="400">Collected By</th>
                                                <th rowspan="1" class="text-center" width="400">Date</th>
                                                <th rowspan="1" class="text-center" width="400">Amount</th>
                                            </tr>
                                            @foreach ($collections as $item)
                                            <tr>
                                                <td class="text-center">{{$item->name}}</td>
                                                <td class="text-center">{{$item->date}}</td>
                                                <td class="text-center">{{$item->amount}}</td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <td class="text-right" colspan="2">Total Paid Amount</td>
                                                <td class="text-center">
                                                    Rs.{{$total}}
                                                </td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
    </section>
@endsection
