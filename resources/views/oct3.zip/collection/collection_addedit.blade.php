@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Collection</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Collection</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="product_form" method="POST" action="{{$route}}">
                            <?php if(isset($unit->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Order</label>
                                        <select class="form-control select2" name="order_id"  id="order_id" style="width: 100%;" required>
                                          <option value="0" selected="selected">Select Order</option>
                                          <?php echo $order_option; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Collected By</label>
                                        <select class="form-control" name="collected_by" style="width: 100%;" required>
                                        <option selected="selected">Select User</option>
                                        <?php echo $admin_option; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Amount<span id="show_details">   (paid : <span style="color: green" id="paid"></span>, pending : <span style="color: orange" id="pending"></span>)</span></label>
                                        <input onchange="getCashByAmount(this.value)" class="form-control" type="number" name="amount" id="amount" required>
                                    </div>     
                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select class="form-control select2" onchange="showDetails(this.value)" name="payment_method_id" style="width: 100%;" required>
                                            <option selected="selected" value="Cash">Cash</option>
                                            <option value="UPI">UPI</option>
                                            <option value="Mixed">Mixed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                               
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input class="form-control" type="date" value="@php echo date("Y-m-d"); @endphp" name="date" id="date">
                                    </div> 
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" name="desc" id="desc"></textarea>
                                    </div>                                  
                                    <div class="col-12">
                                        <input type="hidden" name="id">
                                        <input class="btn btn-success float-right" type="submit" value="Add Collection">
                                    </div>
                                </div>
                                <!-- /.col -->
                            </div>
                            <div id="cash_upi" style="display: none">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class=""><b>UPI</b></label>
                                        <input onchange="getCashAmount(this.value)" type="number" class="form-control"  name="upi" id="upi" value="0">
                                      </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class=""><b>Cash</b></label>
                                        <input readonly type="number" class="form-control" min="1" id="cash" name="cash" value="0">
                                      </div>
                                </div>
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>

$('#order_id').on('change', function() {
  
    if(this.value != 0) {
        var jsonData = JSON.parse(this.value);
        $('#paid').text(jsonData.paid);
        $('#pending').text(jsonData.total - jsonData.paid);
        $('#show_details').show();
    } else {
        $('#show_details').hide();
    }
    

});

    $(document).ready(function () {
        $('#show_details').hide();
        // $(document).on('click', '#product_form', function (e) {
        //     $("form#product_form").validate({
        //         rules: {
        //             name: { required: true},
        //             code: { required: true},
        //             category:{required:true},
        //             unit: { required: true},
        //         },
        //         messages: {
        //             name: { required: "Please enter name"},
        //             code: { required: "Please enter code"},
        //             category: { required: "Please select category"},
        //             unit: { required: "Please enter unit"},
        //         },
        //         focusInvalid: true,
        //         invalidHandler: function () {
        //             $(this).find(":input.error:first").focus();
        //         }
        //     });
        // });
    });

    function showDetails(selectedPayment) {
        if(selectedPayment == "Mixed") {
            $('#cash_upi').show();
        } else {
            $('#cash_upi').hide();
        }
    }
    
    
    function getCashAmount(upi) {
        var total_amount = $('#amount').val();
        $('#cash').val(total_amount - upi);
    }
           
    function getCashByAmount(amount) {
        var upi = $('#upi').val();
        $('#cash').val(amount - upi);
    }
           
    </script>
@endsection