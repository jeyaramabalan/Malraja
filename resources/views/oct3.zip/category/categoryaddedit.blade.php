@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Category</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="">Home</a></li>
                    <li class="breadcrumb-item active">Category</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="customer_form" method="POST" action="{{$route}}">
                            <?php if(isset($category->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input class="form-control" type="text" name="name" id="name" value="<?php if(isset($category->name)){echo $category->name;} ?>" required>
                                    </div>
                                                            
                                    <div class="col-12">
                                        <input type="hidden" name="id" value="<?php if(isset($category->id)){echo $category->id;} ?>">
                                        <input class="btn btn-success float-right" type="submit" value="<?php if(isset($category->id)){echo "Update Category";}else{echo "Add Category";}?>" onclick="validate()">
                                      </div>
                                </div>
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        $(document).on('click', '#customer_form', function (e) {
            $("form#customer_form").validate({
                rules: {
                    name: { required: true},
                    address: { required: true},
                    mobile: { required: true, minlength:10},
                },
                messages: {
                    name: { required: "Please enter name"},
                    mobile: { required: "Please enter valid mobile"},
                    address: { required: "Please enter address"},
                },
                focusInvalid: true,
                invalidHandler: function () {
                    $(this).find(":input.error:first").focus();
                }
            });
        });
    });           
</script>
@endsection