
<nav class="main-header navbar navbar-expand navbar-white navbar-light">

  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="{{route('order.create')}}" class="nav-link {{ Route::is('order.create') ? 'active' : '' }}">New Order</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="{{route('new-pos-order')}}" class="nav-link {{ Route::is('new-pos-order') ? 'active' : '' }}">New POS</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="{{route('order.index')}}" class="nav-link {{ Route::is('order.index') ? 'active' : '' }}">All Orders</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="{{route('customer.create')}}" class="nav-link {{ Route::is('customer.create') ? 'active' : '' }}">Add Customer</a>
    </li>
  </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
      <li class="nav-item">
        <form id="logoutForm" method="POST" action="{{ route('admin.logout') }}">
          @csrf
          <a class="nav-link" onclick="submitForm()" href="#" role="button">
            <i class="fas fa-sign-out-alt"></i>
          </a>
        </form>
      </li>
    </ul>
  </nav>
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-custom elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      {{-- <img src="{{asset('dist/img/logo.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8"> --}}
      <span style="color: white;" class="brand-text font-weight-bold">Malraja Traders</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <!-- <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div>
      </div> -->

      <!-- Sidebar Menu -->
      <nav class="mt-1">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="{{route('dashboard')}}" class="nav-link {{ Route::is('dashboard') ? 'active' : '' }}">
            <i class="nav-icon fas fa-dashboard"></i>
            <p>Dashboard</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('customer.index')}}" class="nav-link {{ Route::is('customer.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-users"></i>
            <p>Customers</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('products.index')}}" class="nav-link {{ Route::is('products.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-cubes"></i>
            <p>Products</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('users')}}" class="nav-link {{ Route::is('users') ? 'active' : '' }}">
            <i class="nav-icon fas fa-user-secret"></i>
            <p>Users</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-chart-pie"></i>
            <p>
              Masters
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview pl-2" style="display: none;">
            <li class="nav-item">
              <a href="{{route('category.index')}}" class="nav-link {{ Route::is('category.index') ? 'active' : '' }}">
                <i class="nav-icon fas fa-user-secret"></i>
                <p>Category</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('unit.index')}}" class="nav-link {{ Route::is('unit.index') ? 'active' : '' }}">
                <p>Unit</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('hsn.index')}}" class="nav-link {{ Route::is('hsn.index') ? 'active' : '' }}">
                <p>HSN</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('expense.index')}}" class="nav-link {{ Route::is('expense.index') ? 'active' : '' }}">
                <p>Expense Type</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('route.index')}}" class="nav-link {{ Route::is('route') ? 'active' : '' }}">
                <p>Route</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="{{route('vendor.index')}}" class="nav-link {{ Route::is('vendor.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-server"></i>
            <p>Vendor</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-shopping-cart"></i>
            <p>
              Orders
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview pl-2" style="display: none;">
            <li class="nav-item">
              <a href="{{route('new-pos-order')}}" class="nav-link {{ Route::is('new-pos-order') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Create POS</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('order.create')}}" class="nav-link {{ Route::is('order.create') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Create Delivery Order</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('order.index')}}" class="nav-link {{ Route::is('order.index') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>All Order</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('get-order-confirmed')}}" class="nav-link {{ Route::is('get-order-confirmed') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Confirmed Order</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('get-order-delivery')}}" class="nav-link {{ Route::is('get-order-delivery') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Pending Delivery</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('get-order-payment')}}" class="nav-link {{ Route::is('get-order-payment') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Pending Payment</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('get-order-completed')}}" class="nav-link {{ Route::is('get-order-completed') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Completed Orders</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('return.index')}}" class="nav-link {{ Route::is('return.index') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Return Orders</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="{{route('purchase.index')}}" class="nav-link {{ Route::is('purchase.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-cart-plus"></i>
            <p>Purchase Order</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('stock')}}" class="nav-link {{ Route::is('stock') ? 'active' : '' }}">
            <i class="nav-icon fas fa-truck"></i>
            <p>Stock</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('dailyexpense.index')}}" class="nav-link {{ Route::is('dailyexpense.index') ? 'active' : '' }}">
            <i class="nav-icon fa fa-tags"></i>
            <p>Daily Expense</p>
          </a>
        </li>
        {{-- <li class="nav-item">
          <a href="{{route('claimeddetails.index')}}" class="nav-link {{ Route::is('claimeddetails.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-credit-card"></i>
            <p>Claimed Details</p>
          </a>
        </li> --}}
        <li class="nav-item">
          <a href="{{route('collection.index')}}" class="nav-link {{ Route::is('collection.index') ? 'active' : '' }}">
            <i class="nav-icon fas fa-inr"></i>
            <p>Collection</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="nav-icon fas fa-shopping-cart"></i>
            <p>
              Reports
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview pl-2" style="display: none;">
            <li class="nav-item">
              <a href="{{route('daily-profit-index')}}" class="nav-link {{ Route::is('daily-profit-index') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Daily Profit Report</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('stock-report')}}" class="nav-link {{ Route::is('stock-report') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Stock Report</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('daily-product-index')}}" class="nav-link {{ Route::is('daily-product-index') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Product Daily Sale Report</p>
              </a>
            </li>
            {{-- <li class="nav-item">
              <a href="{{route('new-pos-order')}}" class="nav-link {{ Route::is('new-pos-order') ? 'active' : '' }}">
                <i class="nav-icon fa fa-arrow-circle-right"></i>
                <p>Daily Report</p>
              </a>
            </li> --}}
          </ul>
        </li>
        {{-- <li class="nav-item">
          <a href="{{route('attendance')}}" class="nav-link {{ Route::is('attendance') ? 'active' : '' }}">
            <p>Attendance</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="{{route('attendance')}}" class="nav-link {{ Route::is('settings') ? 'active' : '' }}">
            <p>Seetings</p>
          </a>
        </li> --}}
      </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <script>
    function submitForm() {
      $("form#logoutForm").submit();
    }
  </script>