@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Expense</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Expense</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form id="product_form" method="POST" action="{{$route}}">
                            <?php if(isset($unit->name)){?>@method('PATCH')<?php }else {?>@method('POST')<?php }?>
                            @csrf
                            <div class="row">
                                  <div class="form-group col-12">
                                      <label>Expense</label>
                                      <input class="form-control" type="text" name="unit" id="unit" value="<?php if(isset($unit->name)){echo $unit->name;} ?>" required>
                                  </div>
                                <div class="col-12">
                                    <input type="hidden" name="id" value="<?php if(isset($unit->id)){echo $unit->id;} ?>">
                                    <input class="btn btn-success float-right" type="submit" value="<?php if(isset($unit->id)){echo "Update Expense";}else{echo "Add Expense";}?>" onclick="validate()">
                                </div>
                                <!-- /.col -->
                            </div>
                        </form>    
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>
<script>
    $(document).ready(function () {
        // $(document).on('click', '#product_form', function (e) {
        //     $("form#product_form").validate({
        //         rules: {
        //             name: { required: true},
        //             code: { required: true},
        //             category:{required:true},
        //             unit: { required: true},
        //         },
        //         messages: {
        //             name: { required: "Please enter name"},
        //             code: { required: "Please enter code"},
        //             category: { required: "Please select category"},
        //             unit: { required: "Please enter unit"},
        //         },
        //         focusInvalid: true,
        //         invalidHandler: function () {
        //             $(this).find(":input.error:first").focus();
        //         }
        //     });
        // });
    });
    
           
    </script>
@endsection