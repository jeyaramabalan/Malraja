@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Daily Profit</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="   ">Home</a></li>
                    <li class="breadcrumb-item active">Daily Profit</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        {{-- <a href="{{$route}}" class="btn btn-primary float-right">Add</a> --}}
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="POST" action="{{route('daily-profit')}}">
                            @method('POST')
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <label>Date</label>
                                    <input class="form-control" type="text" id="datetimepicker" name="date" />
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select class="form-control select2" name="payment_method_id" id="payment_method_id" style="width: 100%;" required>
                                          <option selected="selected" value="">Select Payment Method</option>
                                          <option value="UPI">UPI</option>
                                          <option  value="cash">Cash</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <label>Clieck to view</label>
                                    <input type="buton" onclick="getData()" class="form-control btn btn-success" value="View"/>
                                </div>
                            </div>
                            
                            <div id="master">

                            </div>
                            <input id="generate" style="display: none" type="submit" class="form-control btn btn-primary" value="Generate" />
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>

<script>

function getData()
{
    var date = $("#datetimepicker").val();
    var payment_method_id = $("#payment_method_id").val();
    $.ajax({
        type:"post",
        url: '{{route("daily-profit-get")}}',
        data:{_token: '{{csrf_token()}}', date:date, payment_method_id:payment_method_id},
        success:function(res)
        {
            if(res)
            {
                var output = $.parseJSON(res);
                $('#master').empty();
                $('#generate').show();
                $('#master').html(output);
            }
        }
    });
}

function generateData()
{
    var date = $("#date").val();
    var payment_method_id = $("#payment_method_id").val();
    $.ajax({
        type:"post",
        url: '{{route("daily-profit")}}',
        data:{_token: '{{csrf_token()}}', date:date, payment_method_id:payment_method_id},
        success:function(res)
        {
            if(res)
            {
                var output = $.parseJSON(res);
                $('#master').empty();
                $('#master').html(output);
            }
        }
    });
}

</script>

@endsection