@extends('layouts.app')
@section('content')

<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Stock Report</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="">Home</a></li>
                    <li class="breadcrumb-item active">Stock Report</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        {{-- <a href="{{$route}}" class="btn btn-primary float-right">Add</a> --}}
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="POST" action="{{$route}}">
                            @method('POST')
                            @csrf
                            <div class="row">
                                <div class="col-3">
                                    <label>Category</label>
                                    <select class="form-control select2" name="cat_id" style="width: 100%;" >
                                        <option value="" selected="selected">Select Category</option>
                                        <?php echo $category; ?>
                                    </select>
                                </div>
                                <div class="col-3">
                                    <label>Category</label>
                                    <select class="form-control select2" name="hsn_id" style="width: 100%;" >
                                        <option value="" selected="selected">Select HSN</option>
                                        <?php echo $hsn; ?>
                                    </select>
                                </div>
                                <div class="col-2">
                                    <label>Click to generate</label>
                                    <input type="submit" class="form-control btn btn-success" value="Generate"/>
                                    {{-- <input type="buton" onclick="getData()" class="form-control btn btn-success" value="View"/> --}}
                                </div>
                            </div>
                            
                            <div id="master">

                            </div>
                            <input id="generate" style="display: none" type="submit" class="form-control btn btn-primary" value="Generate" />
                        </form>

                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
</section>

<script>

function getData()
{
    var date = $("#datetimepicker").val();
    $.ajax({
        type:"post",
        url: '{{route("get-stock-report")}}',
        data:{_token: '{{csrf_token()}}', date:date},
        success:function(res)
        {
            if(res)
            {
                var output = $.parseJSON(res);
                $('#master').empty();
                $('#generate').show();
                $('#master').html(output);
            }
        }
    });
}

function generateData()
{
    var date = $("#date").val();
    $.ajax({
        type:"post",
        url: '{{route("daily-profit")}}',
        data:{_token: '{{csrf_token()}}', date:date},
        success:function(res)
        {
            if(res)
            {
                var output = $.parseJSON(res);
                $('#master').empty();
                $('#master').html(output);
            }
        }
    });
}

</script>

@endsection